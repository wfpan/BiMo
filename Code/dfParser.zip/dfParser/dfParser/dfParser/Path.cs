﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using System.IO;
using System.Xml;

/*************************************
 * 计算平均最短路径
 * qyy
 * 2009.4.9
 * **********************************/
namespace dfParser
{
    class Path
    {
        //表示网络的一个节点
        struct Node
        {
            public string name;
            public int pathLen;
            public ArrayList neighbers;
            public Node(string s) { name = s; pathLen = 0; neighbers = new ArrayList(); }
        }

        //xml file to parse
        private string filename;
        //arraylist to save all the nodes of the net 
        private ArrayList nodes;

        //constructor
        public Path(string name)
        {
            filename = name;
            nodes = new ArrayList();
        }

        //指向的邻居
        private void outNodes(string type)
        {
            try
            {
                XmlReader reader = XmlReader.Create(filename);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {
                        reader.ReadToDescendant("name");
                        reader.ReadStartElement("name");
                        String s_name = reader.ReadString();
                        if (type.Equals("feature"))
                        {
                            if (s_name.EndsWith(")") || s_name.EndsWith("}"))
                            {
                                Node n = new Node(s_name);
                                while (reader.ReadToNextSibling("outbound"))
                                {
                                    if (reader.GetAttribute("confirmed").Equals("yes"))
                                    {
                                        reader.ReadStartElement("outbound");
                                        String e_name = reader.ReadString();
                                        if (e_name.EndsWith(")") || e_name.EndsWith("}"))
                                        {
                                            n.neighbers.Add(e_name);
                                        }
                                    }
                                }
                                nodes.Add(n);
                            }
                        }
                            //类节点和包结点
                        else
                        {
                            Node n = new Node(s_name);
                            while (reader.ReadToNextSibling("outbound"))
                            {
                                if (reader.GetAttribute("confirmed").Equals("yes"))
                                {
                                    reader.ReadStartElement("outbound");
                                    String e_name = reader.ReadString();
                                    n.neighbers.Add(e_name);
                                }
                            }
                            nodes.Add(n);
                        }
                    }
                } while (reader.ReadToFollowing(type));
            }
            catch (Exception e)
            {
                MessageBox.Show("error during parsing!\n" + e.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //进入的邻居
        private void inNodes(string type)
        {
            int index = -1;
            ArrayList tempArr = (ArrayList)nodes.Clone();
            nodes.Clear();
            try
            {
                XmlReader reader = XmlReader.Create(filename);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {
                        reader.ReadToDescendant("name");
                        reader.ReadStartElement("name");
                        String s_name = reader.ReadString();
                        if (type.Equals("feature"))
                        {
                            if (s_name.EndsWith(")") || s_name.EndsWith("}"))
                            {
                                //Node n = new Node(s_name);
                                index++;
                                Node temp = (Node)tempArr[index];
                                while (reader.ReadToNextSibling("inbound"))
                                {
                                    if (reader.GetAttribute("confirmed").Equals("yes"))
                                    {
                                        reader.ReadStartElement("inbound");
                                        String e_name = reader.ReadString();
                                        if (e_name.EndsWith(")") || e_name.EndsWith("}"))
                                        {
                                            //n.neighbers.Add(e_name);
                                            //for (int i = 0; i < nodes.Count; i++)
                                            //{
                                            //    Node temp = (Node)nodes[i];
                                            //    if (s_name.Equals(temp.name)&&(!temp.neighbers.Contains (e_name)))
                                            //    {
                                            //        nodes.RemoveAt(i);
                                            //        temp.neighbers.Add(e_name);
                                            //        nodes.Add(temp);
                                            //    }
                                            //}
                                            
                                            if (!temp.neighbers.Contains(e_name))
                                            {
                                                temp.neighbers.Add(e_name);
                                            }
                                        }
                                    }
                                }
                                //nodes.Add(n);
                                nodes.Add(temp);
                            }
                        }
                        //类节点和包结点
                        else
                        {
                           // Node n = new Node(s_name);
                            index++;
                            Node temp = (Node)tempArr[index];
                            while (reader.ReadToNextSibling("inbound"))
                            {
                                if (reader.GetAttribute("confirmed").Equals("yes"))
                                {
                                    reader.ReadStartElement("inbound");
                                    String e_name = reader.ReadString();
                                    //n.neighbers.Add(e_name);
                                    //for (int i = 0; i < nodes.Count; i++)
                                    //{
                                    //    Node temp = (Node)nodes[i];
                                    //    if (s_name.Equals(temp.name) && (!temp.neighbers.Contains(e_name)))
                                    //    {
                                    //        nodes.RemoveAt(i);
                                    //        temp.neighbers.Add(e_name);
                                    //        nodes.Add(temp);
                                    //    }
                                    //}
                                    
                                    if (!temp.neighbers.Contains(e_name))
                                    {
                                        temp.neighbers.Add(e_name);
                                    }

                                }
                            }
                            nodes.Add(temp);
                            //nodes.Add(n);
                        }
                    }
                } while (reader.ReadToFollowing(type));
            }
            catch (Exception e)
            {
                MessageBox.Show("error during parsing!\n" + e.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //得到所有邻居
        private void fill(string type)
        {
            outNodes(type);
            inNodes(type);
        }

        //判断数组中是否包含同名元素
        private bool contains(ArrayList arr, Node n)
        {
            for (int i = 0; i < arr.Count; i++)
            {
                Node temp = (Node)arr[i];
                if (temp.name.Equals(n.name))
                {
                    return true;
                }
            }

            return false;
        }

        //search all the shortest path and calculate the average
        public double averageShortestPath(string type)
        {
            fill(type);
            int totalPath = 0;
            int totalNum = nodes.Count;
            string itemStr = "";

            ArrayList foundNodes = new ArrayList();
            for (int i = 0; i < nodes.Count; i++)
            {
                Node start = (Node)nodes[i];
                foundNodes.Add(start);
                for (int j = 0; j < foundNodes.Count; j++)
                {
                    Node media = (Node)foundNodes[j];
                    for(int x=0;x<media.neighbers.Count;x++)
                    {
                        for (int k = i + 1; k < nodes.Count; k++)
                        {
                            Node end = (Node)nodes[k];
                            if(contains (foundNodes,end))
                            {
                                continue;
                            }
                            else if (isNeighber(media,end))//&&(!foundNodes.Contains(end)))
                            {
                                end.pathLen = media.pathLen + 1;
                                itemStr += (i+1).ToString() + "\t" + (k+1).ToString() + "\tpath: " + end.pathLen + "\r\n";
                                totalPath += end.pathLen;
                                foundNodes.Add(end);
                            }
                        }
                    }
                    if (foundNodes.Count == totalNum-i)
                    {
                        break;
                    }
                }
                //此时，nodes集合中剩下的节点都是不可达的 
                totalPath += (totalNum -i-foundNodes.Count) * totalNum;
                foundNodes.Clear();
            }

            double result = (2 * totalPath) / (totalNum * (totalNum - 1));
            string info = "\r\n处理文件："
                + filename
                + "\r\n结点类型："
                + type
                + "\r\n\r\n所有可达节点间的最短路径为：\r\n\r\n"
                + itemStr
                + "\r\n平均最短路径："
                + result;

            char[] outStr = ".xml".ToCharArray();
            String outFlieName = filename.Trim(outStr).ToString() + "_spath.txt";
            StreamWriter wr = new StreamWriter(outFlieName);
            wr.Write(info);
            wr.Close();
            MessageBox.Show("\n处理结束，结果保存在\n\n" + outFlieName, "处理结果");
            return result;
        }

        ////////////////////////////////////////////////////////////////
        //计算平均聚集系数
        //第一步，得到一个结点的邻居结点集合
        private ArrayList getNeighbers(Node n, ArrayList arr)
        {
            ArrayList neighberArr = new ArrayList();
            for (int i = 0; i < arr.Count; i++)
            {
               
                Node temp = (Node)arr[i];
                if (n.neighbers.Contains(temp.name))
                {
                    neighberArr.Add(temp);
                }
            }
            return neighberArr;
        }

        //判断一个结点是否是另一个结点的邻居
        private bool isNeighber(Node n1, Node n2)
        {
            if (n1.neighbers.Contains(n2.name))
            {
                return true;
            }

            return false;
        }

        //计算平均聚集系数
        public double averageC(string type)
        {
            fill(type);
            double total = 0;
            double single = 0;
            int realEdgeNum = 0;
            string itemStr = "";
            for (int i = 0; i < nodes.Count; i++)
            {
                realEdgeNum = 0;
                Node n = (Node)nodes[i];
                ArrayList neiArr = getNeighbers(n, nodes);
                double num = neiArr.Count;

                //没有邻居
                if (num == 0)
                {
                    single = 0;
                }
                else if (num == 1)
                {
                    single = 0;
                }
                else
                {
                    for (int j = 0; j < neiArr.Count; j++)
                    {
                        Node n1 = (Node)neiArr[j];
                        for (int k = j + 1; k < neiArr.Count; k++)
                        {
                            Node n2 = (Node)neiArr[k];
                            if (isNeighber(n1, n2))
                            {
                                realEdgeNum++;
                            }
                        }
                    }
                    single = (double)(2 * realEdgeNum) / (double)(num * (num - 1));
                }
                itemStr += (i+1).ToString()+ "\t" + single.ToString() + "\r\n";
                total += single;
            }

            double result = total / nodes.Count;
            string info = "\r\n处理文件："
                + filename
                + "\r\n结点类型："
                + type
                + "\r\n\r\n各节点的聚集系数为：\r\n\r\n"
                + itemStr
                + "\r\n平均聚集系数："
                + result;

            char[] outStr = ".xml".ToCharArray();
            String outFlieName = filename.Trim(outStr).ToString() + "_coeffient1.txt";
            StreamWriter wr = new StreamWriter(outFlieName);
            wr.Write(info);
            wr.Close();
            MessageBox.Show("\n处理结束，结果保存在\n\n" + outFlieName, "处理结果");
            return result;
        }
    }
}

