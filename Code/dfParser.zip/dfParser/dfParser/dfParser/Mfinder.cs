﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using System.Xml;
using System.Windows.Forms;

/****************************************
 * 转换成mfinder的输入文件格式
 * qyy
 * 2009.4.7
 * **************************************/
namespace dfParser
{

    class Mfinder
    {
        //表示一个节点
        struct Item
        {
            public string name;
            public int flag;
            public Item(string s, int i) { name = s; flag = i; }
        }

        private string fileName;
        private ArrayList datas;

        //构造函数
        public Mfinder(string name)
        {
            fileName = name;
            datas = new ArrayList();

        }

        //搜索填充数据集
        private void fillData(String type)
        {
            int iflag = 0;
            try
            {
                XmlReader reader = XmlReader.Create(fileName);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {
                        reader.ReadToDescendant("name");
                        reader.ReadStartElement("name");
                        String s_name = reader.ReadString();
                        if (type.Equals("feature"))
                        {
                            if (s_name.EndsWith(")") || s_name.EndsWith("}"))
                            {
                                iflag++;
                                Item i = new Item(s_name, iflag);
                                datas.Add(i);
                            }
                        }
                        else
                        {
                            iflag++;
                            Item i = new Item(s_name, iflag);
                            datas.Add(i);
                        }
                    }
                } while (reader.ReadToFollowing(type));
            }
            catch (Exception e)
            {
                MessageBox.Show("error during parsing!\n" + e.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    }

        /*处理p2p、c2c、f2f处理之后的xml文件*/
        public void transform(String type)
        {
            fillData(type);
            String itemStr = "";
            int flag = 0;
            try
            {
                XmlReader reader = XmlReader.Create(fileName);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {
                        reader.ReadToDescendant("name");
                        reader.ReadStartElement("name");
                        String s_name = reader.ReadString();
                        //对于feature节点
                        if (type.Equals("feature"))
                        {
                            if (s_name.EndsWith(")") || s_name.EndsWith("}"))
                            {
                                flag++;
                                while (reader.ReadToNextSibling("outbound"))
                                {
                                    if (reader.GetAttribute("confirmed").Equals("yes"))
                                    {
                                        reader.ReadStartElement("outbound");
                                        String e_name = reader.ReadString();
                                        if (e_name.EndsWith(")") || e_name.EndsWith("}"))
                                        {
                                            for (int i = 0; i < datas.Count; i++)
                                            {
                                                Item temp=(Item)datas[i];
                                                if (temp.name.Equals(e_name))
                                                {
                                                    itemStr += flag
                                                        + "\t"
                                                        + temp.flag
                                                        + "\t"
                                                        + "1"
                                                        + "\r\n";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //对于包节点和类节点
                        else
                        {
                            flag++;
                            while (reader.ReadToNextSibling("outbound"))
                            {
                                if (reader.GetAttribute("confirmed").Equals("yes"))
                                {
                                    reader.ReadStartElement("outbound");
                                    String e_name = reader.ReadString();
                                    for (int i = 0; i < datas.Count; i++)
                                    {
                                        Item temp = (Item)datas[i];
                                        if (temp.name.Equals(e_name))
                                        {
                                            itemStr += flag
                                                + "\t"
                                                + temp.flag
                                                + "\t"
                                                + "1"
                                                + "\r\n";
                                        }
                                    }
                                }
                            }
                        }
                    }

                } while (reader.ReadToFollowing(type));

                //获得转换后的文件名
                char[] outStr = ".xml".ToCharArray();
                String o_name = fileName.Trim(outStr).ToString() + "_mfinder.txt";
                StreamWriter sw = new StreamWriter(o_name);
                sw.Write(itemStr);
                sw.Close();
                MessageBox.Show("文件保存与当前目录", "提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch (Exception e)
            { 
                MessageBox.Show("erorr during parsing!\n" + e.ToString(), "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
