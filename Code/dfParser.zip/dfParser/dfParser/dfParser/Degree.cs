﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

/***********************************
 * 计算度分布
 * qyy
 * 2009.4.6
 * *********************************/
namespace dfParser
{
    class Degree
    {
        //file name
        private string fileName;

        public Degree(string name)
        {
            fileName = name;
        }
        
        /*只通过一次结点的遍历来统计入度和出度*/
        public void calculate(String type)
        {
            bool isConfirmed = false, isFeature = false, isStart = false, isEdge=false;
            int flag = 0, inNum = 0, outNum = 0, total = 0; ;
            string itemStr = "";

            if (type.Equals("feature"))
            {
                isFeature = true;
            }

            try
            {
                XmlReader reader = XmlReader.Create(fileName);
                reader.MoveToContent();

                while (reader.Read())
                {
                    switch (reader.NodeType)
                    {
                        case XmlNodeType.Element://读到开始标记
                            if (reader.Name.Equals(type) && reader.GetAttribute("confirmed").Equals("yes"))
                            {
                                isConfirmed = true;
                                if (!isFeature)
                                    flag++;
                            }
                            else if (reader.Name.Equals("name") && isConfirmed && isFeature)
                            {
                                String name = reader.ReadString();
                                if (name.Contains("{") || name.Contains("("))
                                {
                                    flag++;
                                }
                                else
                                {
                                    isConfirmed = false;
                                }
                            }
                            else if (reader.Name.Equals("outbound") && reader.GetAttribute("confirmed").Equals("yes") && isConfirmed )
                            {
                                if (isFeature)
                                    isStart = true;
                                else
                                    isEdge = true;
                            }
                            else if (reader.Name.Equals("inbound") && reader.GetAttribute("confirmed").Equals("yes") && isConfirmed)
                            {
                                if (isFeature)
                                    isStart = true;
                                else
                                    isEdge = true;
                            }
                            break;
                        case XmlNodeType.Text:
                            if (isConfirmed && isStart &&(reader.Value.Contains("{") || reader.Value.Contains("(")))
                            {
                                isEdge = true;
                                isStart = false;
                            }
                            break;
                        case XmlNodeType.EndElement://读到结束标记，此时一个结点(非方法)已经统计完
                            if (reader.Name.Equals("outbound") && isEdge)
                            {
                                outNum++;
                                total ++;
                                isEdge = false;
                            }
                            else if (reader.Name.Equals("inbound") && isEdge)
                            {
                                inNum++;
                                total ++;
                                isEdge = false;
                            }
                            else if (reader.Name.Equals(type) && isConfirmed)
                            {
                                itemStr += flag.ToString()
                                    + "\tindegree:"
                                    + inNum
                                    + "\toutdegree:"
                                    + outNum
                                    + "\ttotal:"
                                    + (inNum + outNum)
                                    + "\r\n";

                                
                                inNum = 0;
                                outNum = 0;
                                isConfirmed = false;
                            }
                            break;
                    }
                }
                double averge = (double)total / (double)flag;
                itemStr += "\r\n平均度：" + averge;
                char[] outStr = ".xml".ToCharArray();
                String outFlieName = fileName.Trim(outStr).ToString() + "_degree.txt";
                StreamWriter wr = new StreamWriter(outFlieName);
                wr.Write(itemStr);
                wr.Close();
                MessageBox.Show("\n处理结束，结果保存在\n\n" + outFlieName , "处理结果");
            }
            catch (Exception e) 
            {
                MessageBox.Show("解析xml文件出错！","错误",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        } 

    }
}
