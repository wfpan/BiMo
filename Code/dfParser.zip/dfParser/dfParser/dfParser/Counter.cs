﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Xml;
using System.IO;
using System.Windows.Forms;

/***************************
 * 统计网络中结点数目的类
 * qyy
 * *************************/
namespace dfParser
{
    class Counter
    {
        //节点的数目
        private int numOfNodes, numOfEdges;
        //要解析的文件
        private string fileName;
        //表示解析是否出错
        private bool error;

        public bool Error
        {
            get
            {
                return error;
            }
        }

        /*构造函数*/
        public Counter (string s)     
        {
            numOfNodes = 0;
            numOfEdges = 0;
            fileName = s;
            error = false;
        }
        
        /*统计网络中边和结点的数目*/
        public void count(string type)
        {
            try
            {
                XmlReader reader = XmlReader.Create(fileName);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {

                        if (type.Equals("feature"))
                        {
                            reader.ReadToDescendant("name");
                            reader.ReadStartElement("name");
                            String s_name = reader.ReadString();
                            if (s_name.EndsWith(")") || s_name.EndsWith("}"))
                            {
                                numOfNodes++;
                                while (reader.ReadToNextSibling("outbound"))
                                {
                                    if (reader.GetAttribute("confirmed").Equals("yes"))
                                    {
                                        reader.ReadStartElement("outbound");
                                        String e_name = reader.ReadString();
                                        if (e_name.EndsWith(")") || e_name.EndsWith("}"))
                                        {
                                            numOfEdges++;
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            numOfNodes++;
                            reader.ReadToDescendant("name");
                            while (reader.ReadToNextSibling("outbound"))
                            {
                                if (reader.GetAttribute("confirmed").Equals("yes"))
                                {   
                                    numOfEdges++;
                                }
                            }
                        }
                    }

                } while (reader.ReadToFollowing(type));

                //将本次处理的信息保存于文件中
                string info = "\r\n文件名："
                    + fileName
                    + "\r\n结点类型："
                    + type
                    + "\r\n结点数目："
                    + numOfNodes
                    + "\r\n边的数目："
                    + numOfEdges;

                char[] outStr = ".xml".ToCharArray();
                string outFlieName = fileName.Trim(outStr).ToString() + "_netScale.txt";
                StreamWriter sw = new StreamWriter(outFlieName);
                sw.Write(info);
                sw.Close();

                MessageBox.Show("\n处理结束，结果保存在\n\n" + outFlieName ,"处理结果");
            }
            catch (Exception e)
            {
                MessageBox.Show("解析xml文件出错！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
