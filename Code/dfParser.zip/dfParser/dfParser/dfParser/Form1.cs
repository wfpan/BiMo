﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace dfParser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        ///*响应方式2*/
        

        /*选择要处理的文件*/
        private void btnSelect_Click(object sender, EventArgs e)
        {
            tbxFile.Clear();
            openFileDialog1.Title = "选择文件";
            openFileDialog1.Filter = "xml files (*.xml)|*.xml";
            openFileDialog1.FileName = "";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                tbxFile.Text = openFileDialog1.FileName;
            }
        }

        /*计算各种参数*/
        private void btnHandle_Click(object sender, EventArgs e)
        {
            if (tbxFile.Text == "")
            {
                MessageBox.Show("请选择要处理的文件！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                btnSelect.Select();
            }
            else if (cbxName.Text == "")
            {
                MessageBox.Show("请选择计算的参数！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (cbxType.Text == "")
            {
                MessageBox.Show("请选择结点类型！","提示",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                cbxType.Focus();
            }            
            else//开始进行处理
            {
                label4.Visible = true;

                //获取文件名
                string fileName = openFileDialog1.FileName;
               

                //获取结点类型
                string type = cbxType.Text;
                if (type.Equals("包结点"))
                {
                    type = "package";
                }
                else if (type.Equals("类结点"))
                {
                    type = "class";
                }
                else if (type.Equals("方法结点"))
                {
                    type = "feature";
                }

                //获取要计算的参数
                string name = cbxName.Text;

                //计算结点数和边数
                if (name.Equals("网络规模"))
                {
                    Counter c1 = new Counter(fileName);
                    c1.count(type);
                }
                else if (name.Equals("度分布"))
                {
                    Degree d1 = new Degree(fileName);
                    d1.calculate(type);
                }
                else if (name.Equals("平均最短路径"))
                {
                    Path p1 = new Path(fileName);
                    p1.averageShortestPath(type);
                }
                else if (name.Equals("聚集系数"))
                {
                    Path p2 = new Path(fileName);
                    p2.averageC(type);
                }
                else if (name.Equals("Pajek输入文件"))
                {
                    Parser p1 = new Parser(fileName);
                    p1.xml2txt(type);
                }
                else if (name.Equals("Mfinder输入文件"))
                {
                    Mfinder m1 = new Mfinder(fileName);
                    m1.transform(type);
                }

                label4.Visible = false;
            }

        }

        /*加裁窗体时*/
        private void Form1_Load(object sender, EventArgs e)
        {
            label4.Visible = false;
            progressBar1.Visible = false;
        }

       
    }
}
