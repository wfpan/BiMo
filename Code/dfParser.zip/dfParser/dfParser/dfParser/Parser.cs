﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;

/******************************
 * 处理df分析之后得到xml文件
 * 以得到所需要的数据
 * qyy
 * 2009.3.11
 * ****************************/
namespace dfParser
{
    class Parser
    {
        //要处理的文件名
        private String fileName;

        //构造函数
        public Parser(String s)
        {
            fileName = s;
        }

        /*处理p2p、c2c、f2f处理之后的xml文件*/
        public void xml2txt(String type)
        {
            String pairStr = "";
            try
            {
                XmlReader reader = XmlReader.Create(fileName);

                reader.MoveToContent();
                reader.ReadToDescendant(type);

                do
                {
                    if (reader.GetAttribute("confirmed").Equals("yes"))
                    {

                        reader.ReadToDescendant("name");
                        reader.ReadStartElement("name");
                        String s_name = reader.ReadString();
                        if (type.Equals("feature"))
                        {
                            if(s_name.EndsWith(")")||s_name.EndsWith("}"))
                                while (reader.ReadToNextSibling("outbound"))
                                {
                                    if (reader.GetAttribute("confirmed").Equals("yes"))
                                    {
                                        reader.ReadStartElement("outbound");
                                        String e_name = reader.ReadString();
                                        if (e_name.EndsWith(")")||e_name.EndsWith("}"))
                                        {
                                            pairStr += s_name + "\t" + e_name + "\r\n";
                                        }
                                    }
                                }
                        }
                        //对于包节点和类节点
                        else
                        {
                            while (reader.ReadToNextSibling("outbound"))
                            {
                                if (reader.GetAttribute("confirmed").Equals("yes"))
                                {
                                    reader.ReadStartElement("outbound");
                                    String e_name = reader.ReadString();
                                    pairStr += s_name + "\t" + e_name + "\r\n";
                                }
                            }
                        }
                    }

                } while (reader.ReadToFollowing(type));

                //获得转换后的文件名
                char[] outStr = ".xml".ToCharArray();
                String outFileName = fileName.Trim(outStr).ToString() + "_pajek.txt";
                StreamWriter wr = new StreamWriter(outFileName);
                wr.Write(pairStr);
                wr.Close();
                MessageBox.Show("\n处理结束，结果保存在:\n"+fileName,"处理结果");
            }
            catch (Exception e)
            {
                MessageBox.Show("解析xml文件出错", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
