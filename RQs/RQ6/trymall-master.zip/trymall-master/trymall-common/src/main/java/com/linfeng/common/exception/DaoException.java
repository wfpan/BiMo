package com.linfeng.common.exception;

import com.linfeng.common.response.ApiCode;

/**
 * @author linfeng
 * @date 2020/8/29 20:13
 */
public class DaoException extends TrymallException{
    private static final long serialVersionUID = -6912618737345878854L;

    public DaoException(String message) {
        super(message);
    }

    public DaoException(Integer errorCode, String message) {
        super(errorCode, message);
    }

    public DaoException(ApiCode apiCode) {
        super(apiCode);
    }
}
