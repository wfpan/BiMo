package com.linfeng.common.exception;

import com.linfeng.common.response.ApiCode;

/**
 * @author linfeng
 * @date 2020/8/29 20:14
 */
public class UnAuthenticatedException extends TrymallException {
    public UnAuthenticatedException(String message) {
        super(message);
    }

    public UnAuthenticatedException(Integer errorCode, String message) {
        super(errorCode, message);
    }

    public UnAuthenticatedException(ApiCode apiCode) {
        super(apiCode);
    }
}
