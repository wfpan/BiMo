package com.linfeng.common.constant;

/**
 * @author linfeng
 * @date 2021/1/19 14:35
 */
public class RedisKeyConstant {

    private static final String APPLICATION_NAME = "trymall-application:";


    public static final String TOKEN = APPLICATION_NAME + "token:";


    public final static String OPEN_INTERFACE = APPLICATION_NAME + "open-interface:";


    public final static String IP_LIBRARY = APPLICATION_NAME + "ip-library:";


    public final static String API_DATA = APPLICATION_NAME + "api-data:";


    public final static String ALIYUNOSS_IMPL = APPLICATION_NAME + "oss:";


    public final static String SYSTEMCONFIG_IMPL = APPLICATION_NAME + "SystemConfigImpl:";


    public final static String CAROUSEL_IMPL = APPLICATION_NAME + "BannerImpl:";

}

