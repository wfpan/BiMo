package com.linfeng.common.constant;

/**
 * @author linfeng
 * @date 2020/10/18 16:25
 */
public interface ShopConstants {


    String SHOP_FROM_WX="wx";
    String USER_LOGIN_REFUSE="账号或密码不正确";
    String LOGIN_SUCCESS="登录成功";
    String PHONE_REGISTER="手机号已注册";
    String ACCOUNT_NOT_EXIST="账号不存在";
    String CODE_TIME="10分钟内有效:";
    String CODE_TIMES="10分钟内有效";
    String CODE_TEST_VALUE="测试阶段验证码:";
    String CODE_SEND_SUCCESS="发送成功，请注意查收";
    String CODE_SEND_FAIL="发送失败：";
    String ADMIN_LOGIN_REFUSE="账号或密码不正确";
    /**
     * IP归属地查询
     */
    String IP_URL = "http://whois.pconline.com.cn/ipJson.jsp?ip=%s&json=true";
    /**
     * redis订单未付款key
     */
    String REDIS_ORDER_OUTTIME_UNPAY = "order:unpay:";
    /**
     * 短信验证码长度
     */
    int SMS_SIZE = 6;
    /**
     * 短信缓存时间
     */
    long SMS_REDIS_TIME = 600L;

    String ONE="1";

    /**
     * oss存储
     */
    String ALIYUN="aliyun";
    String QINIU="qiniu";
}
