package com.linfeng.common.exception;

import com.linfeng.common.response.ApiCode;

/**
 * 业务异常
 * @author linfeng
 * @date 2020/8/29 20:11
 */
public class BusinessException extends TrymallException {
    private static final long serialVersionUID = -2303357122330162359L;

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(Integer errorCode, String message) {
        super(errorCode, message);
    }

    public BusinessException(ApiCode apiCode) {
        super(apiCode);
    }
}
