package com.linfeng.common.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author linfeng
 * @date 2021/1/20 15:18
 */
@Setter
@Getter
public class SystemMessageVo implements Serializable {

    private String id;

    private Long createDate;

    /**
     * 消息标题
     */
    private String title;

    /**
     * 作者
     */
    private String author;

    /**
     * 消息内容
     */
    private String content;

    /**
     * 消息主图
     */
    private String image;

}

