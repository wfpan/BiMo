package com.linfeng.common.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author linfeng
 * @date 2021/1/19 14:59
 */
@Setter
@Getter
public class SystemConfigVo implements Serializable {

    /**
     * 联系方式
     */
    private String contact;

    /**
     * 关于我们
     */
    private String about;

    /**
     * 网站底部
     */
    private String footer;

}

