package com.linfeng.common.domain;

import java.io.Serializable;

/**
 * <p>
 * 管理员
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public class TrymallAdmin implements Serializable {

    private static final long serialVersionUID=1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 创建时间
     */
    private Long createDate;

    /**
     * 删除判断
     */
    private Integer delFlag;

    /**
     * 备注
     */
    private String remarks;

    /**
     * 更新时间
     */
    private Long updateDate;

    private String username;

    private String password;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Long createDate) {
        this.createDate = createDate;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Long getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Long updateDate) {
        this.updateDate = updateDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "TrymallAdmin{" +
        "id=" + id +
        ", createDate=" + createDate +
        ", delFlag=" + delFlag +
        ", remarks=" + remarks +
        ", updateDate=" + updateDate +
        ", username=" + username +
        ", password=" + password +
        "}";
    }
}
