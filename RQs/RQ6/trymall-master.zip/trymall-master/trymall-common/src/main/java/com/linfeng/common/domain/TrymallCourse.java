package com.linfeng.common.domain;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;

/**
 * <p>
 * 新手教程模块
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public class TrymallCourse implements Serializable {

    private static final long serialVersionUID=1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ID_WORKER_STR)
    private String id;

    /**
     * 创建时间
     */
    @TableField(value = "create_date",fill = FieldFill.INSERT)
    private Long createDate;

    /**
     * 删除判断
     */
    @TableLogic
    private Integer delFlag;

    /**
     * 备注
     */
    private String remarks;

    /**
     * 更新时间
     */
    @TableField(value = "update_date",fill = FieldFill.UPDATE)
    private Long updateDate;

    /**
     * 教程标题
     */
    private String title;

    /**
     * 教程内容
     */
    private String content;

    /**
     * 作者
     */
    private String author;

    /**
     * 主图地址
     */
    private String image;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Long createDate) {
        this.createDate = createDate;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Long getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Long updateDate) {
        this.updateDate = updateDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "TrymallCourse{" +
        "id=" + id +
        ", createDate=" + createDate +
        ", delFlag=" + delFlag +
        ", remarks=" + remarks +
        ", updateDate=" + updateDate +
        ", title=" + title +
        ", content=" + content +
        ", author=" + author +
        ", image=" + image +
        "}";
    }
}
