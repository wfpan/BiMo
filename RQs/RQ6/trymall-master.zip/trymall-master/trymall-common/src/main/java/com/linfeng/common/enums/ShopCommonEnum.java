package com.linfeng.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author linfeng
 * @date 2021/1/13 14:32
 */

@Getter
@AllArgsConstructor
public enum ShopCommonEnum {


    ENABLE_1(1,"开启"),
    ENABLE_2(2,"关闭");

    private Integer value;
    private String desc;

}
