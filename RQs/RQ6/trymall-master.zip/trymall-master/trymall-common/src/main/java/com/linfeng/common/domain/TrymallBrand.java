package com.linfeng.common.domain;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author linfeng
 * @date 2020/8/27 21:34
 */
@TableName("trymall_brand")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class TrymallBrand {

    @TableId
    private Integer id;

    private String name;

    private String description;

    @NotBlank(message = "请上传品牌商图片")
    private String picUrl;

    private Byte sortOrder;

    private BigDecimal floorPrice;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date addTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;

    @TableLogic
    private Boolean deleted;
}
