package com.linfeng.common.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author linfeng
 * @date 2021/1/20 14:47
 */
@Setter
@Getter
public class CourseVo implements Serializable {

    private String id;

    private Long createDate;

    /**
     * 教程标题
     */
    private String title;

    /**
     * 作者
     */
    private String author;

    /**
     * 教程内容
     */
    private String content;

    /**
     * 主图地址
     */
    private String image;

}
