package com.linfeng.common.exception;

import com.linfeng.common.response.ApiCode;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author linfeng
 * @date 2020/8/29 20:04
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TrymallException extends RuntimeException {

        private static final long serialVersionUID = -2470461654663264392L;

        private Integer errorCode;
        private String message;

        public TrymallException() {
            super();
        }

        public TrymallException(String message) {
            super(message);
            this.message = message;
        }

        public TrymallException(Integer errorCode, String message) {
            super(message);
            this.errorCode = errorCode;
            this.message = message;
        }

        public TrymallException(ApiCode apiCode) {
            super(apiCode.getMessage());
            this.errorCode = apiCode.getCode();
            this.message = apiCode.getMessage();
        }

        public TrymallException(String message, Throwable cause) {
            super(message, cause);
        }

        public TrymallException(Throwable cause) {
            super(cause);
        }



}
