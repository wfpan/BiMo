package com.linfeng.common.vo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author linfeng
 * @date 2021/1/19 16:22
 */
@Setter
@Getter
public class BannerVo implements Serializable {

    /**
     * 点击跳转地址
     */
    private String clickUrl;

    /**
     * 轮播主图
     */
    private String image;

}