package com.linfeng.db.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linfeng.common.domain.TrymallSearchhistory;
import com.linfeng.db.base.CoreMapper;

/**
 * <p>
 * 搜索历史表 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2020-10-18
 */
public interface TrymallSearchhistoryMapper extends CoreMapper<TrymallSearchhistory> {

}
