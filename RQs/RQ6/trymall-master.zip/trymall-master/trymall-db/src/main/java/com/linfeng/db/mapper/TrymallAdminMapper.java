package com.linfeng.db.mapper;

import com.linfeng.common.domain.TrymallAdmin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 管理员 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallAdminMapper extends BaseMapper<TrymallAdmin> {

}
