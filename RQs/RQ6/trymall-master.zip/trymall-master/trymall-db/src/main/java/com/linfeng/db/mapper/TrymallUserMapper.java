package com.linfeng.db.mapper;

import com.linfeng.common.domain.TrymallUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2020-12-25
 */
public interface TrymallUserMapper extends BaseMapper<TrymallUser> {

}
