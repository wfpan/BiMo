package com.linfeng.db.mapper;

import com.linfeng.common.domain.system.Log;
import com.linfeng.db.base.CoreMapper;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @author linfeng
 * @date 2021/1/12 20:14
 */
@Repository
@Mapper
public interface LogMapper extends CoreMapper<Log> {

}
