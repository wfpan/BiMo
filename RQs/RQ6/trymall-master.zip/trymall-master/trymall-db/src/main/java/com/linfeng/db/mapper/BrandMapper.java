package com.linfeng.db.mapper;

import com.linfeng.common.domain.TrymallBrand;
import com.linfeng.db.base.CoreMapper;
import org.springframework.stereotype.Repository;

/**
 * @author linfeng
 * @date 2020/8/27 21:57
 */
@Repository
public interface BrandMapper extends CoreMapper<TrymallBrand> {

}
