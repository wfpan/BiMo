package com.linfeng.db.mapper;

import com.linfeng.common.domain.system.SystemConfig;
import com.linfeng.db.base.CoreMapper;
import org.springframework.stereotype.Repository;

/**
 * @author linfeng
 * @date 2021/1/11 14:12
 */
@Repository
public interface SystemConfigMapper extends CoreMapper<SystemConfig> {

}