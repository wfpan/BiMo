package com.linfeng.db.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallSystemMessage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linfeng.common.vo.SystemMessageVo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 系统消息模块 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallSystemMessageMapper extends BaseMapper<TrymallSystemMessage> {


    @Select("<script>" +
            "select * from trymall_system_message " +
            "<where> " +
            "<if test=\"systemMessage.title != null and systemMessage.title !=''\">" +
            "and title like concat('%',#{systemMessage.title},'%') " +
            "</if>" +
            "<if test=\"systemMessage.content != null and systemMessage.content !=''\">" +
            "and content like concat('%',#{systemMessage.content},'%') " +
            "</if>" +
            "</where>" +
            "order by create_date desc" +
            "</script>")
    List<TrymallSystemMessage> page(@Param("systemMessage") TrymallSystemMessage systemMessage, Page page);

    @Select("select id,create_date,title,content,author,image from trymall_system_message " +
            "order by create_date desc " +
            "limit 0,30")
    List<SystemMessageVo> getList();

    @Select("select id,create_date,title,content,author,image from trymall_system_message " +
            "where id = #{articleId}")
    SystemMessageVo article(@Param("articleId") String articleId);

    @Delete("delete from trymall_system_message where id = #{id}")
    void deleteId(@Param("id") String id);
}
