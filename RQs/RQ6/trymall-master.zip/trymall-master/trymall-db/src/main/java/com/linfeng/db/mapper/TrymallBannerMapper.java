package com.linfeng.db.mapper;

import com.linfeng.common.domain.tbk.TrymallBanner;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linfeng.common.vo.BannerVo;
import org.apache.ibatis.annotations.Select;
import org.springframework.boot.Banner;

import java.util.List;

/**
 * <p>
 * 首页轮播模块 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
public interface TrymallBannerMapper extends BaseMapper<TrymallBanner> {


    @Select("select image,click_url from trymall_banner order by sort asc")
    List<BannerVo> getListBySort();

    @Select("select * from trymall_banner order by create_date desc")
    List<TrymallBanner> getListByCreateDate();
}
