package com.linfeng.db.mapper;

import com.linfeng.common.domain.system.QiniuContent;
import com.linfeng.db.base.CoreMapper;

/**
 * @author linfeng
 * @date 2021/1/12 22:20
 */
public interface QiniuContentMapper extends CoreMapper<QiniuContent> {
}
