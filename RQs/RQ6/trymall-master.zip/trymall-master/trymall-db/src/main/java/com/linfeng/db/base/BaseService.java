package com.linfeng.db.base;

/**
 * @author linfeng
 * @date 2020/8/27 21:49
 */
import com.baomidou.mybatisplus.extension.service.IService;


public interface BaseService<T> extends IService<T> {

}