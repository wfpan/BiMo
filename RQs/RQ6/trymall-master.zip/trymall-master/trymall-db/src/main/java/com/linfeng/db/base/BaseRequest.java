package com.linfeng.db.base;

import lombok.Getter;
import lombok.Setter;

/**
 * 好单库请求基类
 * @author linfeng
 * @date 2021/1/19 19:17
 */
@Setter
@Getter
public class BaseRequest {

    private String apikey;

}
