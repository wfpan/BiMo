package com.linfeng.db.mapper;

import com.linfeng.common.domain.tbk.TrymallSysConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linfeng.common.vo.SystemConfigVo;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 系统各种信息模块 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
public interface TrymallSysConfigMapper extends BaseMapper<TrymallSysConfig> {


    @Select("select contact,about,footer from trymall_sys_config")
    SystemConfigVo getSystemConfigVo();
}
