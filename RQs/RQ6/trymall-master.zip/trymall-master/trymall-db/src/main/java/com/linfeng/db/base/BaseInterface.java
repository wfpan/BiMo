package com.linfeng.db.base;

/**
 * @author linfeng
 * @date 2021/1/19 19:16
 */
public interface BaseInterface {

    String getApiUrl();

    String getRequestMethod();

}
