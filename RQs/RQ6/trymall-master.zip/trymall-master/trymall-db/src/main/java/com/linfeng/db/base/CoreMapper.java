package com.linfeng.db.base;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author linfeng
 * @date 2020/8/24 10:50
 */
public interface CoreMapper<T> extends BaseMapper<T> {

}
