package com.linfeng.db.mapper;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallCourse;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.linfeng.common.vo.CourseVo;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 教程模块 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallCourseMapper extends BaseMapper<TrymallCourse> {

    @Select("select id,create_date,title,content,author,image from trymall_course " +
            "order by create_date desc " +
            "limit 0,50")
    List<CourseVo> getList();

    @Select("select id,create_date,title,content,author,image from trymall_course " +
            "where id = #{articleId}")
    CourseVo article(@Param("articleId") String articleId);

    @Select("<script>" +
            "select * from trymall_course " +
            "<where> " +
            "<if test=\"course.title != null and course.title !=''\">" +
            "and title like concat('%',#{course.title},'%') " +
            "</if>" +
            "<if test=\"course.content != null and course.content !=''\">" +
            "and content like concat('%',#{course.content},'%') " +
            "</if>" +
            "</where>" +
            "order by create_date desc" +
            "</script>")
    List<TrymallCourse> page(@Param("course") TrymallCourse course, Page page);


    @Delete("delete from trymall_course where id = #{id}")
    void deleteId(@Param("id") String id);
}
