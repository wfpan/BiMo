package com.linfeng.db.mapper;

import com.linfeng.common.domain.TrymallIssue;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 常见问题表 Mapper 接口
 * </p>
 *
 * @author linfeng
 * @since 2020-08-28
 */
public interface TrymallIssueMapper extends BaseMapper<TrymallIssue> {

}
