package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * @author linfeng
 * @date 2021/1/20 16:15
 */
public class ApiGoodsRates extends BaseRequest implements BaseInterface {

    //宝贝id
    private String itemid;

    //推广位pid
    private String pid;

    //淘宝账号名称
    private String tb_name;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/ratesurl";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.POST;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getTb_name() {
        return tb_name;
    }

    public void setTb_name(String tb_name) {
        this.tb_name = tb_name;
    }
}
