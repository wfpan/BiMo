package com.linfeng.api.service;

import com.linfeng.common.domain.system.QiniuContent;
import com.linfeng.db.base.BaseService;

/**
 * @author linfeng
 * @date 2021/1/12 22:16
 */
public interface QiniuContentService extends BaseService<QiniuContent> {


}
