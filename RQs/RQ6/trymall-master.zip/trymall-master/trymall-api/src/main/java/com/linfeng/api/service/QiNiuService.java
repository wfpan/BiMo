package com.linfeng.api.service;

import com.linfeng.common.domain.system.QiniuContent;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author linfeng
 * @date 2021/1/12 21:46
 */
public interface QiNiuService {

    QiniuContent upload(MultipartFile file);
}
