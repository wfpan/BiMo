package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallBrand;
import com.linfeng.db.base.BaseService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author linfeng
 * @date 2020/8/27 21:10
 */

@Service
public interface BrandService extends BaseService<TrymallBrand> {

    public TrymallBrand findById();

    public TrymallBrand findByBrandId(Integer id);

    public void deleteBrandById(Integer id);

    public List<TrymallBrand> findAll();

    public List<TrymallBrand> findAllByPage(int page,int limit);
}
