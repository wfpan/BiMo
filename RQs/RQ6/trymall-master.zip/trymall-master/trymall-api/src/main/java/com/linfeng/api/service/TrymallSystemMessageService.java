package com.linfeng.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallSystemMessage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.linfeng.common.vo.SystemMessageVo;

import java.util.List;

/**
 * <p>
 * 系统消息模块 服务类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallSystemMessageService extends IService<TrymallSystemMessage> {


    Page<TrymallSystemMessage> page(TrymallSystemMessage systemMessage, Page page);

    List<SystemMessageVo> getList();

    SystemMessageVo article(String articleId);
    void deleteById(String id);
}
