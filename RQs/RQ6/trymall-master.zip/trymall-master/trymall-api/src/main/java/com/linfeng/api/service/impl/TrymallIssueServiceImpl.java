package com.linfeng.api.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.linfeng.common.domain.TrymallBrand;
import com.linfeng.common.domain.TrymallIssue;
import com.linfeng.db.mapper.TrymallIssueMapper;
import com.linfeng.api.service.TrymallIssueService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 常见问题表 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2020-08-28
 */
@Service
public class TrymallIssueServiceImpl extends ServiceImpl<TrymallIssueMapper, TrymallIssue> implements TrymallIssueService {

    @Override
    public List<TrymallIssue> findAll() {
        List<TrymallIssue> trymallIssues = this.baseMapper.selectList(Wrappers.<TrymallIssue>lambdaQuery()
                .eq(TrymallIssue::getDeleted, 0));
        return trymallIssues;
    }
}
