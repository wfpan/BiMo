package com.linfeng.api.controller;


import com.linfeng.api.service.TrymallSearchhistoryService;
import com.linfeng.common.domain.TrymallSearchhistory;
import com.linfeng.common.response.ApiResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * <p>
 * 搜索历史表 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2020-10-18
 */
@RestController
@RequestMapping("/trymallSearchhistory")
public class TrymallSearchhistoryController {


    @Autowired
    private TrymallSearchhistoryService trymallSearchhistoryService;


    @GetMapping("/api/findAll")
    public ApiResult<List<TrymallSearchhistory>> findAll(){
        List<TrymallSearchhistory> all = trymallSearchhistoryService.findAll();
        return ApiResult.ok(all);
    }


}

