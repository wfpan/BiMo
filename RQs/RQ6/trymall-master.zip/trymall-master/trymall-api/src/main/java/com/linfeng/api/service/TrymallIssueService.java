package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallIssue;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 常见问题表 服务类
 * </p>
 *
 * @author linfeng
 * @since 2020-08-28
 */
public interface TrymallIssueService extends IService<TrymallIssue> {

    public List<TrymallIssue> findAll();
}
