package com.linfeng.api.service.impl;

import com.linfeng.common.domain.TrymallAdmin;
import com.linfeng.db.mapper.TrymallAdminMapper;
import com.linfeng.api.service.TrymallAdminService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 管理员 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
@Service
public class TrymallAdminServiceImpl extends ServiceImpl<TrymallAdminMapper, TrymallAdmin> implements TrymallAdminService {

}
