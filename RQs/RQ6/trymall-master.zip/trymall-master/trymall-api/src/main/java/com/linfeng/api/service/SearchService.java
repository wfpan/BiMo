package com.linfeng.api.service;

/**
 * @author linfeng
 * @date 2021/1/20 13:29
 */
public interface SearchService {

    String keyword();

    String goods(String keyword,Integer tag,Integer page);
}
