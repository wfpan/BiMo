package com.linfeng.api.util.hdk;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author linfeng
 * @date 2021/1/19 19:04
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "hdk")
public class HdkConfig {

    private String pid = "pid";
    private String appkey = "appkey";
    private String tbName = "tbName";

}
