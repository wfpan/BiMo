package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 今日值得买
 * @author linfeng
 * @date 2021/1/19 19:23
 */
public class ApiDeserver extends BaseRequest implements BaseInterface {

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/get_deserve_item";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

}
