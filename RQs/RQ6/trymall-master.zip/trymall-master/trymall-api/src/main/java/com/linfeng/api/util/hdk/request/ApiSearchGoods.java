package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * 搜索商品
 * @author linfeng
 * @date 2021/1/20 13:35
 */
public class ApiSearchGoods extends BaseRequest implements BaseInterface {

    //搜索词
    private String keyword;

    //page
    private Integer min_id;

    //返回条数
    private Integer back = 20;

    //淘宝分页
    private Integer tb_p;

    //是否只取有券商品：0否；1是，默认是0
    private Integer is_coupon = 1;

    private Integer sort;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/supersearch";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {

        try {
            String encode = URLEncoder.encode(keyword, "UTF-8");
            encode = URLEncoder.encode(encode, "UTF-8");
            this.keyword = encode;
        } catch (UnsupportedEncodingException e) {
            this.keyword = "";
        }
    }

    public Integer getMin_id() {
        return min_id;
    }

    public void setMin_id(Integer min_id) {
        this.min_id = min_id;
        this.tb_p = min_id;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }
}

