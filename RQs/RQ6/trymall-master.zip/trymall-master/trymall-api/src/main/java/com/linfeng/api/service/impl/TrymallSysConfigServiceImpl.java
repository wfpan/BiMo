package com.linfeng.api.service.impl;

import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.common.constant.RedisKeyConstant;
import com.linfeng.common.domain.tbk.TrymallSysConfig;
import com.linfeng.common.vo.SystemConfigVo;
import com.linfeng.db.mapper.TrymallSysConfigMapper;
import com.linfeng.api.service.TrymallSysConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 系统各种信息模块 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
@Service
public class TrymallSysConfigServiceImpl extends ServiceImpl<TrymallSysConfigMapper, TrymallSysConfig> implements TrymallSysConfigService {


    @Autowired
    private RedisUtils redisUtils;


    @Override
    public SystemConfigVo getSystemConfigVo() {
        String redisKey = RedisKeyConstant.SYSTEMCONFIG_IMPL + "SystemConfig";

        SystemConfigVo systemConfigVo = (SystemConfigVo)redisUtils.get(redisKey);
        if (systemConfigVo == null) {

            systemConfigVo = super.baseMapper.getSystemConfigVo();
            if (systemConfigVo == null) {
                return null;
            }
            redisUtils.set(redisKey,systemConfigVo);
        }
        return systemConfigVo;
    }

    @Override
    public void create(TrymallSysConfig systemConfig) {
        Integer count = super.baseMapper.selectCount(null);
        if (count > 0) {
            String redisKey = RedisKeyConstant.SYSTEMCONFIG_IMPL + "SystemConfig";

            redisUtils.del(redisKey);

            super.baseMapper.updateById(systemConfig);
        } else {
            super.baseMapper.insert(systemConfig);
        }
    }
}
