package com.linfeng.api.service.impl;

import com.linfeng.api.service.QiniuContentService;
import com.linfeng.common.domain.system.QiniuContent;
import com.linfeng.db.base.impl.BaseServiceImpl;
import com.linfeng.db.mapper.QiniuContentMapper;
import org.springframework.stereotype.Service;

/**
 * @author linfeng
 * @date 2021/1/12 22:17
 */

@Service
public class QiniuContentServiceImpl extends BaseServiceImpl<QiniuContentMapper, QiniuContent> implements QiniuContentService {


}
