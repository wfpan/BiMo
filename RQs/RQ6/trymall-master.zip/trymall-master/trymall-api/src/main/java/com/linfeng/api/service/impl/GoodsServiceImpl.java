package com.linfeng.api.service.impl;

import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.api.service.GoodsService;
import com.linfeng.api.util.hdk.HdkApiRequest;
import com.linfeng.api.util.hdk.HdkConfig;
import com.linfeng.api.util.hdk.request.ApiGoodsDetails;
import com.linfeng.api.util.hdk.request.ApiGoodsLike;
import com.linfeng.api.util.hdk.request.ApiGoodsRates;
import com.linfeng.common.constant.RedisKeyConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author linfeng
 * @date 2021/1/20 13:13
 */
@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private HdkConfig hdkConfig;


    @Override
    public String getDetails(String goodsId) {
        String redisKey = RedisKeyConstant.API_DATA + "goods-details:" + goodsId;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiGoodsDetails apiGoodsDetails = new ApiGoodsDetails();
            apiGoodsDetails.setApikey(hdkConfig.getAppkey());
            apiGoodsDetails.setItemid(goodsId);
            try {
                String response = HdkApiRequest.doRequest(apiGoodsDetails);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String like(String goodsId) {
        String redisKey = RedisKeyConstant.API_DATA + "goods-like:" + goodsId;
        String data = (String) redisUtils.get(redisKey);
        if (data == null || data.equals("")) {
            ApiGoodsLike apiGoodsLike = new ApiGoodsLike();
            apiGoodsLike.setApikey(hdkConfig.getAppkey());
            apiGoodsLike.setItemid(goodsId);
            try {
                String response = HdkApiRequest.doRequest(apiGoodsLike);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String rates(String goodsId) {
        String redisKey = RedisKeyConstant.API_DATA + "goods-rates:" + goodsId;
        String data = (String) redisUtils.get(redisKey);
        if (data == null || data.equals("")) {
            ApiGoodsRates apiGoodsRates = new ApiGoodsRates();
            apiGoodsRates.setApikey(hdkConfig.getAppkey());
            apiGoodsRates.setItemid(goodsId);
            apiGoodsRates.setPid(hdkConfig.getPid());
            apiGoodsRates.setTb_name(hdkConfig.getTbName());
            try {
                String response = HdkApiRequest.doRequest(apiGoodsRates);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }
}
