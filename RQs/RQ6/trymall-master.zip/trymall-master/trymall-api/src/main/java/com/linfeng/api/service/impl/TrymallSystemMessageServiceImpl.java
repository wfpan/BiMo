package com.linfeng.api.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallSystemMessage;
import com.linfeng.common.vo.SystemMessageVo;
import com.linfeng.db.mapper.TrymallSystemMessageMapper;
import com.linfeng.api.service.TrymallSystemMessageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 系统消息模块 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
@Service
public class TrymallSystemMessageServiceImpl extends ServiceImpl<TrymallSystemMessageMapper, TrymallSystemMessage> implements TrymallSystemMessageService {

    @Override
    public Page<TrymallSystemMessage> page(TrymallSystemMessage systemMessage, Page page) {
        return page.setRecords(super.baseMapper.page(systemMessage,page));
    }

    @Override
    public List<SystemMessageVo> getList() {

        return super.baseMapper.getList();
    }

    @Override
    public SystemMessageVo article(String articleId) {

        return super.baseMapper.article(articleId);
    }

    @Override
    public void deleteById(String id) {
        super.baseMapper.deleteId(id);
    }
}
