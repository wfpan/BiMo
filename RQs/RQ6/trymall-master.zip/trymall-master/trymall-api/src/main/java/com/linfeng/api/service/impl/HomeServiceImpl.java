package com.linfeng.api.service.impl;

import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.api.service.HomeService;
import com.linfeng.api.util.hdk.HdkApiRequest;
import com.linfeng.api.util.hdk.HdkConfig;
import com.linfeng.api.util.hdk.request.*;
import com.linfeng.common.constant.RedisKeyConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author linfeng
 * @date 2021/1/19 19:10
 */
@Service
public class HomeServiceImpl implements HomeService {


    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private HdkConfig hdkConfig;


    @Override
    public String deserver() {

        String redisKey = RedisKeyConstant.API_DATA + "deserver";
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiDeserver apiDeserver = new ApiDeserver();
            apiDeserver.setApikey(hdkConfig.getAppkey());
            try {
                String response = HdkApiRequest.doRequest(apiDeserver);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String hot(Integer cid) {
        String redisKey = RedisKeyConstant.API_DATA + "hot:" + cid;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiHot apiHot = new ApiHot();
            apiHot.setCid(cid);
            apiHot.setApikey(hdkConfig.getAppkey());
            try {
                String response = HdkApiRequest.doRequest(apiHot);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String talent() {
        String redisKey = RedisKeyConstant.API_DATA + "talent";
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiTalent apiTalent = new ApiTalent();
            apiTalent.setApikey(hdkConfig.getAppkey());
            try {
                String response = HdkApiRequest.doRequest(apiTalent);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String talentArticle(String articleId) {
        String redisKey = RedisKeyConstant.API_DATA + "talent-article:" + articleId;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiTalentArticle talentArticle = new ApiTalentArticle();
            talentArticle.setId(articleId);
            talentArticle.setApikey(hdkConfig.getAppkey());
            try {
                String response = HdkApiRequest.doRequest(talentArticle);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;

    }

    @Override
    public String district(Integer page, Integer tag, Integer type, Integer category) {
        String redisKey = RedisKeyConstant.API_DATA + "district:" + page + "-" + tag + "-" + type + "-" + category;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiColumn apiColumn = new ApiColumn();
            apiColumn.setApikey(hdkConfig.getAppkey());
            apiColumn.setCid(category);
            apiColumn.setMin_id(page);
            apiColumn.setType(type);
            apiColumn.setSort(tag);
            try {
                String response = HdkApiRequest.doRequest(apiColumn);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;

    }

    @Override
    public String brand(Integer page, Integer tag) {
        String redisKey = RedisKeyConstant.API_DATA + "brand:" + page + "-" + tag;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiBrand apiBrand = new ApiBrand();
            apiBrand.setApikey(hdkConfig.getAppkey());
            apiBrand.setMin_id(page);
            apiBrand.setBrandcat(tag);
            try {
                String response = HdkApiRequest.doRequest(apiBrand);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }


}
