package com.linfeng.api.util.oss;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author linfeng
 * @date 2021/1/21 15:26
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "aliyun")
public class AliyunOss {

    private String domainName = "domainName";
    private String endpoint = "endpoint";
    private String keyId = "keyId";
    private String keySecret = "keySecret";
    private String bucketName = "bucketName";
}
