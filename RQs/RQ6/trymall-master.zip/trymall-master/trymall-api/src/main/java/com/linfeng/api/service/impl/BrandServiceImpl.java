package com.linfeng.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.api.service.BrandService;
import com.linfeng.common.domain.TrymallBrand;
import com.linfeng.db.base.impl.BaseServiceImpl;
import com.linfeng.db.mapper.BrandMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author linfeng
 * @date 2020/8/27 21:11
 */
@Service
public class BrandServiceImpl extends BaseServiceImpl<BrandMapper,TrymallBrand> implements BrandService {

    @Autowired
    private BrandMapper brandMapper;

    @Override
    public TrymallBrand findById() {

        QueryWrapper<TrymallBrand> wrapper = new QueryWrapper<>();
        wrapper.eq("deleted",1);
        return brandMapper.selectOne(wrapper);
    }

    @Override
    public TrymallBrand findByBrandId(Integer id) {
        return brandMapper.selectById(id);
    }

    @Override
    public void deleteBrandById(Integer id) {
        this.baseMapper.deleteById(id);
    }

    @Override
    public List<TrymallBrand> findAll() {
        List<TrymallBrand> storeCouponUsers = this.baseMapper.selectList(Wrappers.<TrymallBrand>lambdaQuery()
                        .eq(TrymallBrand::getDeleted, 0));
        return storeCouponUsers;
    }

    @Override
    public List<TrymallBrand> findAllByPage(int page,int limit) {
        QueryWrapper<TrymallBrand> wrapper= new QueryWrapper<>();
        wrapper.eq("deleted",0);
        Page<TrymallBrand> pageModel = new Page<>(page, limit);
        IPage<TrymallBrand> iPage = this.baseMapper.selectPage(pageModel, wrapper);
//        System.out.println("总页数:" + iPage.getPages());
//        System.out.println("总记录数:" + iPage.getTotal());
        List<TrymallBrand> records = iPage.getRecords();
        return records;
    }


}
