package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 获取达人说文章
 * @author linfeng
 * @date 2021/1/19 20:41
 */
public class ApiTalentArticle extends BaseRequest implements BaseInterface {

    /**
     * 文章id
     */
    private String id;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/talent_article";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
