package com.linfeng.api.controller;

import com.linfeng.api.service.DiscoveryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author linfeng
 * @date 2021/1/20 12:36
 */
@RestController
@RequestMapping(value="discovery")
public class DiscoveryController {


    @Autowired
    private DiscoveryService discoveryService;

    /**
     * 发现 精选单品
     */
    @GetMapping("/handpick")
    public Object handpick(Integer page) {

        return discoveryService.handpick(page);
    }

    /**
     * 发现 好货专场
     */

    @GetMapping("/news")
    public Object news(Integer page) {

        return discoveryService.news(page);
    }

    /**
     * 发现 精选主题 list
     */
    @GetMapping("themeList")
    public Object themeList() {

        return discoveryService.themeList();
    }

    /**
     * 发现 精选主题 item
     */
    @GetMapping("theme")
    public Object theme(Integer themeId) {

        return discoveryService.theme(themeId);
    }

}
