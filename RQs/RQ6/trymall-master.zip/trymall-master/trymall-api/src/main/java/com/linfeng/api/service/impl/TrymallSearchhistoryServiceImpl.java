package com.linfeng.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallSearchhistory;
import com.linfeng.db.mapper.TrymallSearchhistoryMapper;
import com.linfeng.api.service.TrymallSearchhistoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.linfeng.common.constant.ShopConstants.SHOP_FROM_WX;

/**
 * <p>
 * 搜索历史表 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2020-10-18
 */
@Service
public class TrymallSearchhistoryServiceImpl extends ServiceImpl<TrymallSearchhistoryMapper, TrymallSearchhistory> implements TrymallSearchhistoryService {

    @Override
    public List<TrymallSearchhistory> findByUserId(int userId,int page,int limit) {
        QueryWrapper<TrymallSearchhistory> wrapper= new QueryWrapper<>();
        wrapper.eq("uid",userId);
        Page<TrymallSearchhistory> pageModel = new Page<>(page, limit);
        IPage<TrymallSearchhistory> iPage = this.baseMapper.selectPage(pageModel, wrapper);
        List<TrymallSearchhistory> records = iPage.getRecords();
        return records;
    }

    @Override
    public List<TrymallSearchhistory> findAll() {
        List<TrymallSearchhistory> trymallIssues = this.baseMapper.selectList(Wrappers.<TrymallSearchhistory>lambdaQuery()
                .eq(TrymallSearchhistory::getFroms, SHOP_FROM_WX));

        return trymallIssues;
    }

    @Override
    public TrymallSearchhistory findById(int id) {
        TrymallSearchhistory trymallSearchhistory = this.baseMapper.selectById(id);
        return trymallSearchhistory;
    }


}
