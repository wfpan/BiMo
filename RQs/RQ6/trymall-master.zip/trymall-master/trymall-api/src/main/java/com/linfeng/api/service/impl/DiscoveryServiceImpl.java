package com.linfeng.api.service.impl;

import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.api.service.DiscoveryService;
import com.linfeng.api.util.hdk.HdkApiRequest;
import com.linfeng.api.util.hdk.HdkConfig;
import com.linfeng.api.util.hdk.request.ApiHandpick;
import com.linfeng.api.util.hdk.request.ApiNews;
import com.linfeng.api.util.hdk.request.ApiTheme;
import com.linfeng.api.util.hdk.request.ApiThemeList;
import com.linfeng.common.constant.RedisKeyConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author linfeng
 * @date 2021/1/20 12:38
 */
@Service
public class DiscoveryServiceImpl implements DiscoveryService {

    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private HdkConfig hdkConfig;

    @Override
    public String handpick(Integer page) {
        String redisKey = RedisKeyConstant.API_DATA + "handpick:" + page;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiHandpick apiHandpick = new ApiHandpick();
            apiHandpick.setApikey(hdkConfig.getAppkey());
            apiHandpick.setMin_id(page);
            try {
                String response = HdkApiRequest.doRequest(apiHandpick);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String news(Integer page) {
        String redisKey = RedisKeyConstant.API_DATA + "news:" + page;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiNews apiNews = new ApiNews();
            apiNews.setApikey(hdkConfig.getAppkey());
            apiNews.setMin_id(page);
            try {
                String response = HdkApiRequest.doRequest(apiNews);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String themeList() {
        String redisKey = RedisKeyConstant.API_DATA + "themeList";
        String data = (String) redisUtils.get(redisKey);
        if (data == null || data.equals("")) {
            ApiThemeList apiThemeList = new ApiThemeList();
            apiThemeList.setApikey(hdkConfig.getAppkey());
            try {
                String response = HdkApiRequest.doRequest(apiThemeList);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }

    @Override
    public String theme(Integer themeId) {
        String redisKey = RedisKeyConstant.API_DATA + "theme:" + themeId;
        String data = (String) redisUtils.get(redisKey);

        if (data == null || data.equals("")) {
            ApiTheme apiTheme = new ApiTheme();
            apiTheme.setApikey(hdkConfig.getAppkey());
            apiTheme.setId(themeId);

            try {
                String response = HdkApiRequest.doRequest(apiTheme);
                redisUtils.set(redisKey,response,1,TimeUnit.HOURS);
                return response;
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }
        return data;
    }
}
