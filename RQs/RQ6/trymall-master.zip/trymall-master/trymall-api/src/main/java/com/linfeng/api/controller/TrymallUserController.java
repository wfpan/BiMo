package com.linfeng.api.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2020-12-25
 */
@Controller
@RequestMapping("/trymallUser")
public class TrymallUserController {

}

