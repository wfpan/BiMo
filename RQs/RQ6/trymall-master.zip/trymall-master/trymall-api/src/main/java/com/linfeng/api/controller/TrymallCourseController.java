package com.linfeng.api.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.api.annotation.AdminCheck;
import com.linfeng.api.service.TrymallCourseService;
import com.linfeng.common.domain.TrymallCourse;
import com.linfeng.common.response.ApiCode;
import com.linfeng.common.response.ApiResult;
import com.linfeng.common.vo.CourseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 教程模块 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
@RestController
@RequestMapping("/course")
public class TrymallCourseController {


    @Autowired
    private TrymallCourseService trymallCourseService;


    @GetMapping("/list")
    public ApiResult getList(){
        List<CourseVo> listBySort = trymallCourseService.getList();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,listBySort);
    }

    @GetMapping("/article")
    public ApiResult article(String articleId){
        CourseVo article = trymallCourseService.article(articleId);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,article);
    }

    @AdminCheck
    @GetMapping("/page")
    public ApiResult page(TrymallCourse course, Page page) {
        Page<TrymallCourse> trymallCoursePage = trymallCourseService.page(course, page);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,trymallCoursePage);
    }

    @GetMapping("/count")
    public ApiResult count(){
        int count = trymallCourseService.count();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,count);
    }

    @AdminCheck
    @GetMapping("/single")
    public ApiResult findOne(String courseId){
        TrymallCourse trymallCourse = trymallCourseService.getById(courseId);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,trymallCourse);
    }

    @AdminCheck
    @PostMapping("/create")
    public ApiResult save(@RequestBody TrymallCourse course){
        if(trymallCourseService.save(course)){
            return ApiResult.result(ApiCode.SUCCESS);
        }
        return ApiResult.result(ApiCode.ERROR);
    }

    @AdminCheck
    @PostMapping("/alter")
    public ApiResult update(@RequestBody TrymallCourse courses){
        if(trymallCourseService.updateById(courses)){
            return ApiResult.result(ApiCode.SUCCESS);
        }
        return ApiResult.result(ApiCode.ERROR);
    }

    @AdminCheck
    @PostMapping("/delete/{courseId}")
    public ApiResult delete(@PathVariable String courseId){
        trymallCourseService.deleteById(courseId);
        return ApiResult.result(ApiCode.SUCCESS);
    }

}

