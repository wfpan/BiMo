package com.linfeng.api.util.oss;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author linfeng
 * @date 2021/1/12 21:53
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "qiniu")
public class QiniuConfig {
    private String maxSize = "maxSize";
    private String accesskey = "accesskey";
    private String bucket = "bucket";
    private String host = "host";
    private String secretKey = "secretKey";
    private String type = "type";
    private String zone = "zone";
}
