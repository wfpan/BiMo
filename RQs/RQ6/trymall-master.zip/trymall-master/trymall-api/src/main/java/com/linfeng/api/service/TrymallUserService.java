package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author linfeng
 * @since 2020-12-25
 */
public interface TrymallUserService extends IService<TrymallUser> {

}
