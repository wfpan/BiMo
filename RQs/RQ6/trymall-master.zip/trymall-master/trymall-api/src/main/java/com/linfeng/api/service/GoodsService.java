package com.linfeng.api.service;

/**
 * @author linfeng
 * @date 2021/1/20 13:13
 */
public interface GoodsService {

    /**
     * 商品详情
     * @param goodsId
     * @return
     */
    String getDetails(String goodsId);

    /**
     * 商品详情页的猜你喜欢
     * @param goodsId
     * @return
     */
    String like(String goodsId);

    /**
     * 申请商品高佣
     */
    String rates(String goodsId);


}
