package com.linfeng.api.util;

/**
 * @author linfeng
 * @date 2021/1/19 19:14
 */
public final class HttpRequestMethod {

    public final static String GET = "GET";

    public final static String POST = "POST";

}
