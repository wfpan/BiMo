package com.linfeng.api.param;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

/**
 * @author linfeng
 * @date 2020/12/25 14:32
 */
@Getter
@Setter
public class LoginParam {

    @NotBlank(message = "用户名必填")
    private String username;

    @NotBlank(message = "密码必填")
    private String password;

    private String spread;
}
