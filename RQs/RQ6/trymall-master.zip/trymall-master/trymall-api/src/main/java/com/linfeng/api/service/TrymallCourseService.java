package com.linfeng.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.common.domain.TrymallCourse;
import com.baomidou.mybatisplus.extension.service.IService;
import com.linfeng.common.vo.CourseVo;

import java.util.List;

/**
 * <p>
 * 教程模块 服务类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallCourseService extends IService<TrymallCourse> {


    Page<TrymallCourse> page(TrymallCourse course, Page page);

    List<CourseVo> getList();

    CourseVo article(String articleId);

    void deleteById(String id);
}
