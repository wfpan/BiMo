package com.linfeng.api.controller;

import com.linfeng.api.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author linfeng
 * @date 2021/1/20 13:28
 */
@RestController
@RequestMapping(value="search")
public class SearchController {


    @Autowired
    private SearchService searchService;

    @GetMapping("/keyword")
    public Object keyword(){
        return searchService.keyword();
    }

    @GetMapping("goods")
    public Object goods(String keyword,Integer tag,Integer page) {
        return searchService.goods(keyword,tag,page);
    }
}
