package com.linfeng.api.service;

/**
 * @author linfeng
 * @date 2021/1/19 18:57
 */
public interface HomeService {


    String deserver();

    String hot(Integer cid);

    String talent();

    String talentArticle(String articleId);

    String district(Integer page,Integer tag,Integer type,Integer category);

    String brand(Integer page,Integer tag);
}
