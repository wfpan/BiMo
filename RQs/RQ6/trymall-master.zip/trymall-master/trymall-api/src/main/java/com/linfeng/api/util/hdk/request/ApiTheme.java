package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 精选主题 item
 * @author linfeng
 * @date 2021/1/20 12:50
 */
public class ApiTheme extends BaseRequest implements BaseInterface {

    /**
     * 主题id
     */
    private Integer id;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/get_subject_item";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}