package com.linfeng.api.redis.Initial;

import com.linfeng.api.service.SystemConfigService;
import com.linfeng.common.domain.system.SystemConfig;
import com.linfeng.api.redis.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author linfeng
 * @date 2021/1/11 13:59
 */
@Slf4j
@Component
public class RedisKeyInitialization implements CommandLineRunner {

    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private SystemConfigService systemConfigService;

    @Override
    public void run(String... args) throws Exception {
        this.redisKeyInitialization();
    }

    /**
     * 初始化redis
     */
    private void redisKeyInitialization() {
        try {
            List<SystemConfig> systemConfigs = systemConfigService.list();
            for (SystemConfig systemConfig : systemConfigs) {
                redisUtils.set(systemConfig.getMenuName(), systemConfig.getValue());
            }
            log.info("\n---------------redisKey初始化成功---------------\n");
        } catch (Exception e) {
            log.error("redisKey初始化失败: {}", e.getMessage());
        }
    }

}
