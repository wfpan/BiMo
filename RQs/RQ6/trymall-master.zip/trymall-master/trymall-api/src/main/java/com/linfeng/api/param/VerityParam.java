package com.linfeng.api.param;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author linfeng
 * @date 2021/1/13 14:25
 */
@Data
public class VerityParam {

    @NotBlank(message = "手机号必填")
    private String phone;

    private String type;
}
