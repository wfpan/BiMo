package com.linfeng.api.service;

import com.linfeng.common.domain.system.Log;
import com.linfeng.db.base.BaseService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.scheduling.annotation.Async;

/**
 * @author linfeng
 * @date 2021/1/12 20:11
 */
public interface LogService extends BaseService<Log> {


    /**
     * 保存用户端日志数据
     * @param username 用户
     * @param ip 请求IP
     * @param joinPoint /
     * @param log 日志实体
     */
    @Async
    void saveApp(String username, String ip, ProceedingJoinPoint joinPoint, Log log, Long uid);
}
