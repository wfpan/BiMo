package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 好货专场
 * @author linfeng
 * @date 2021/1/20 12:44
 */
public class ApiNews extends BaseRequest implements BaseInterface {

    /**
     * 分页
     */
    private Integer min_id;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/subject_hot";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public Integer getMin_id() {
        return min_id;
    }

    public void setMin_id(Integer min_id) {
        this.min_id = min_id;
    }
}
