package com.linfeng.api.controller;

import com.linfeng.api.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author linfeng
 * @date 2021/1/20 13:12
 */
@RestController
@RequestMapping(value="goods")
public class GoodsController {

    @Autowired
    private GoodsService goodsService;


    @GetMapping("/getDetails")
    public Object getDetails(String goodsId) {

        return goodsService.getDetails(goodsId);
    }

    @GetMapping("/like")
    public Object like(String goodsId) {
        return goodsService.like(goodsId);
    }


    @GetMapping("/rates")
    public Object rates(String goodsId) {
        return goodsService.rates(goodsId);
    }

}
