package com.linfeng.api.controller;

import com.linfeng.api.annotation.AppLog;
import com.linfeng.api.service.BrandService;
import com.linfeng.common.domain.TrymallBrand;
import com.linfeng.common.response.ApiResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author linfeng
 * @date 2020/8/24 11:08
 */
@RestController
public class BrandController {

    @Autowired
    private BrandService brandService;


    @GetMapping("/api/brand/{id}")
    public ApiResult<TrymallBrand> getBrandById(@PathVariable Integer id){

        TrymallBrand trymallBrand = brandService.findByBrandId(id);
        return ApiResult.ok(trymallBrand);
    }

    @PostMapping("/api/brand/{id}")
    public ApiResult<Boolean> deleteById(@PathVariable Integer id){
        brandService.deleteBrandById(id);
        return ApiResult.ok();
    }

    @AppLog(value = "查看所有品牌")
    @GetMapping("/api/findAll")
    public ApiResult<List<TrymallBrand>> getUserList(){
        List<TrymallBrand> all = brandService.findAll();
        return ApiResult.ok(all);
    }

    @GetMapping("/api/findAllWithPage")
    public ApiResult<List<TrymallBrand>> getUserListWithPage(@RequestParam(value = "page",defaultValue = "1") int page,
                                                             @RequestParam(value = "limit",defaultValue = "2") int limit){
        List<TrymallBrand> all = brandService.findAllByPage(page, limit);
        return ApiResult.ok(all);
    }


}
