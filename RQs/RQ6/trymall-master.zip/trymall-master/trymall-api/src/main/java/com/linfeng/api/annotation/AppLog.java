package com.linfeng.api.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author linfeng
 * @date 2021/1/12 19:49
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface AppLog {

    String value() default "";//日志描述内容
    int type() default 1; //类型 0-后台 1-用户端

}
