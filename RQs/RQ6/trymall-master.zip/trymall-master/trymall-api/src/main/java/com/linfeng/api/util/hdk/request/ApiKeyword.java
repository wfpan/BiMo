package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 热搜关键词
 * @author linfeng
 * @date 2021/1/20 13:32
 */
public class ApiKeyword extends BaseRequest implements BaseInterface {
    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/hot_key";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }
}

