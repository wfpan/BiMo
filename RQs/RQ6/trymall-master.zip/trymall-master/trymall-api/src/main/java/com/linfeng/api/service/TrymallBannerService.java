package com.linfeng.api.service;

import com.linfeng.common.domain.tbk.TrymallBanner;
import com.baomidou.mybatisplus.extension.service.IService;
import com.linfeng.common.vo.BannerVo;
import org.springframework.boot.Banner;

import java.util.List;

/**
 * <p>
 * 首页轮播模块 服务类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
public interface TrymallBannerService extends IService<TrymallBanner> {


    List<BannerVo> getListBySort();

    List<TrymallBanner> getListByCreateDate();

    void add(TrymallBanner banner);

    void update(TrymallBanner banner);

    void delete(String bannerId);
}
