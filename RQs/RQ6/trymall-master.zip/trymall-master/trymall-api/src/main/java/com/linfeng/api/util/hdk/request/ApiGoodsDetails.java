package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 商品详情
 * @author linfeng
 * @date 2021/1/20 13:16
 */
public class ApiGoodsDetails extends BaseRequest implements BaseInterface {

    //宝贝id
    private String itemid;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/item_detail";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public String getItemid() {
        return itemid;
    }

    public void setItemid(String itemid) {
        this.itemid = itemid;
    }
}