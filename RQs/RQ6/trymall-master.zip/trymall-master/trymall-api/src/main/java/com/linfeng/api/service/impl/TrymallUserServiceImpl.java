package com.linfeng.api.service.impl;

import com.linfeng.common.domain.TrymallUser;
import com.linfeng.db.mapper.TrymallUserMapper;
import com.linfeng.api.service.TrymallUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2020-12-25
 */
@Service
public class TrymallUserServiceImpl extends ServiceImpl<TrymallUserMapper, TrymallUser> implements TrymallUserService {

}
