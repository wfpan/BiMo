package com.linfeng.api.service;

import com.linfeng.common.domain.system.SystemConfig;
import com.linfeng.db.base.BaseService;


/**
 * @author linfeng
 * @date 2021/1/11 14:09
 */
public interface SystemConfigService  extends BaseService<SystemConfig> {

    /**
     * 获取配置值
     * @param name 配置名
     * @return string
     */
    String getData(String name);

}

