package com.linfeng.api.controller;


import com.linfeng.api.annotation.AdminCheck;
import com.linfeng.api.service.TrymallBannerService;
import com.linfeng.common.domain.tbk.TrymallBanner;
import com.linfeng.common.response.ApiCode;
import com.linfeng.common.response.ApiResult;
import com.linfeng.common.vo.BannerVo;
import com.linfeng.common.vo.SystemConfigVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * <p>
 * 首页轮播模块 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
@RestController
@RequestMapping(value = "carousel")
public class TrymallBannerController {

    @Autowired
    private TrymallBannerService bannerService;


    @GetMapping("/getListBySort")
    public ApiResult getBannerListBySort(){
        List<BannerVo> listBySort = bannerService.getListBySort();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,listBySort);
    }

    @AdminCheck
    @GetMapping("/getListByCreateDate")
    public ApiResult getBannerListByDate(){
        List<TrymallBanner> list = bannerService.getListByCreateDate();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,list);
    }

    @AdminCheck
    @PostMapping("/create")
    public ApiResult create(@RequestBody TrymallBanner banner) {
        bannerService.add(banner);
        return ApiResult.result(ApiCode.SUCCESS);
    }

    @AdminCheck
    @PostMapping("/alter")
    public ApiResult update(@RequestBody TrymallBanner banner){
        bannerService.update(banner);
        return ApiResult.result(ApiCode.SUCCESS);
    }

    @AdminCheck
    @PostMapping("/delete/{carouselId}")
    public ApiResult delete(@PathVariable String carouselId) {
        bannerService.delete(carouselId);
        return ApiResult.result(ApiCode.SUCCESS);
    }

    @AdminCheck
    @GetMapping("/single")
    public ApiResult single(String carouselId){
        TrymallBanner byId = bannerService.getById(carouselId);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,byId);
    }
}

