package com.linfeng.api.service.impl;

import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.api.util.StringUtils;
import com.linfeng.common.constant.RedisKeyConstant;
import com.linfeng.common.domain.tbk.TrymallBanner;
import com.linfeng.common.vo.BannerVo;
import com.linfeng.db.mapper.TrymallBannerMapper;
import com.linfeng.api.service.TrymallBannerService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 首页轮播模块 服务实现类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
@Service
public class TrymallBannerServiceImpl extends ServiceImpl<TrymallBannerMapper, TrymallBanner> implements TrymallBannerService {


    @Autowired
    private RedisUtils redisUtils;

    private final static String BANNER="List<Banner>";

    @Override
    public List<BannerVo> getListBySort() {
        String redisKey = RedisKeyConstant.CAROUSEL_IMPL + BANNER;

        List<BannerVo> list = (List) redisUtils.get(redisKey);
        if (list == null) {
            List<BannerVo> listBySort = super.baseMapper.getListBySort();
            if (listBySort == null) {
                return new ArrayList<>();
            }
            redisUtils.set(redisKey, listBySort);
            return listBySort;
        }

        return list;
    }

    @Override
    public List<TrymallBanner> getListByCreateDate() {
        return super.baseMapper.getListByCreateDate();
    }

    @Override
    public void add(TrymallBanner banner) {
        String redisKey = RedisKeyConstant.CAROUSEL_IMPL + BANNER;
        if(redisUtils.get(redisKey)!=null){
            redisUtils.del(redisKey);
        }
        super.baseMapper.insert(banner);
    }

    @Override
    public void update(TrymallBanner banner) {
        String redisKey = RedisKeyConstant.CAROUSEL_IMPL + BANNER;
        redisUtils.del(redisKey);
        super.baseMapper.updateById(banner);
    }

    @Override
    public void delete(String bannerId) {
        String redisKey = RedisKeyConstant.CAROUSEL_IMPL + BANNER;
        redisUtils.del(redisKey);
        super.baseMapper.deleteById(bannerId);
    }
}
