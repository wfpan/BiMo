package com.linfeng.api.config;

import com.linfeng.api.intercepter.AdminAuthCheck;
import com.linfeng.api.intercepter.AuthCheckInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author linfeng
 * @date 2021/1/11 16:09
 */
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {

    @Bean
    public HandlerInterceptor getAuthCheckInterceptor() {
        return new AuthCheckInterceptor();
    }

    @Bean
    public HandlerInterceptor getAdminCheckInterceptor() {
        return new AdminAuthCheck();
    }


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(this.getAuthCheckInterceptor());
        registry.addInterceptor(this.getAdminCheckInterceptor());

    }

}
