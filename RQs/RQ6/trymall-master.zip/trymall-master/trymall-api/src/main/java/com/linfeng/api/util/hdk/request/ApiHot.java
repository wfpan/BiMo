package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 热销榜单
 * @author linfeng
 * @date 2021/1/19 20:18
 */
public class ApiHot extends BaseRequest implements BaseInterface {

    /**
     * 商品类目
     */
    private Integer cid;

    /**
     * 榜单类型：
     * sale_type=1是实时销量榜（近2小时销量）
     * type=2是今日爆单榜
     * type=3是昨日爆单榜
     * type=4是出单指数
     */
    private Integer sale_type = 2;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/sales_list";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }
}
