package com.linfeng.api.controller;

import com.aliyun.oss.OSSClient;
import com.linfeng.api.service.QiNiuService;
import com.linfeng.api.util.oss.AliyunOss;
import com.linfeng.common.constant.ShopConstants;
import com.linfeng.common.domain.system.QiniuContent;
import com.linfeng.common.exception.TrymallException;
import com.linfeng.common.response.ApiCode;
import com.linfeng.common.response.ApiResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 图片上传统一接口
 * @author linfeng
 * @date 2021/1/12 22:31
 */

@RestController
@Slf4j
public class UploadController {

    @Autowired
    private QiNiuService qiNiuService;

    @Autowired
    private AliyunOss aliyunOss;

    @Value("${oss.active}")
    private String active;


    @PostMapping("/oss/upload")
    public ApiResult uploadFile(MultipartFile image) {

        if (ShopConstants.ALIYUN.equals(active)) {
            StringBuilder url = new StringBuilder();
            QiniuContent qiniuContent = qiNiuService.upload(image);
            if ("".equals(url.toString())) {
                url = url.append(qiniuContent.getUrl());
            } else {
                url = url.append("," + qiniuContent.getUrl());
            }
            return ApiResult.result(ApiCode.SUCCESS, ApiCode.SUCCESS.getMessage(), url);
        } else if (ShopConstants.QINIU.equals(active)) {
            try {
                String upload = this.upload(image);
                return ApiResult.result(ApiCode.SUCCESS, ApiCode.SUCCESS.getMessage(), upload);
            } catch (Exception e) {
                return ApiResult.result(ApiCode.FAIL, e.getMessage());
            }
        } else {
            throw new TrymallException("yml未配置图片上传或配置有误");
        }

    }

    private String upload(MultipartFile multipartFile) throws Exception {

        OSSClient ossClient = new OSSClient(
                aliyunOss.getEndpoint(),
                aliyunOss.getKeyId(),
                aliyunOss.getKeySecret());

        String fineUrl = "";
        try {
            InputStream inputStream = multipartFile.getInputStream();
            String originalFilename = multipartFile.getOriginalFilename();
            String[] originalFilenameSplit = originalFilename.split("\\.");
            String fileType = originalFilenameSplit[1];
            fineUrl = UUID.randomUUID().toString().replaceAll("-", "");
            fineUrl += "." + fileType;
            ossClient.putObject(aliyunOss.getBucketName(), fineUrl, inputStream);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception();
        } finally {
            ossClient.shutdown();
        }

        return aliyunOss.getDomainName() + "/" + fineUrl;
    }

}
