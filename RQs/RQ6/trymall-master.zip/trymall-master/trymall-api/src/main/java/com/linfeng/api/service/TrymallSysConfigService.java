package com.linfeng.api.service;

import com.linfeng.common.domain.tbk.TrymallSysConfig;
import com.baomidou.mybatisplus.extension.service.IService;
import com.linfeng.common.vo.SystemConfigVo;

/**
 * <p>
 * 系统各种信息模块 服务类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
public interface TrymallSysConfigService extends IService<TrymallSysConfig> {


    SystemConfigVo getSystemConfigVo();

    void create(TrymallSysConfig systemConfig);
}
