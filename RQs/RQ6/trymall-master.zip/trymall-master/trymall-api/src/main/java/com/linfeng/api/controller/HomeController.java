package com.linfeng.api.controller;

import com.linfeng.api.service.HomeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 首页 好单库api请求接口
 * @author linfeng
 * @date 2021/1/19 18:55
 */
@RestController
@RequestMapping(value="home")
public class HomeController {

    @Autowired
    private HomeService homeService;

    @GetMapping("/deserver")
    public Object deServer() {
        return homeService.deserver();
    }

    @GetMapping("/hot")
    public Object hot(Integer cid) {
        return homeService.hot(cid);
    }

    @GetMapping("/talent")
    public Object talent() {
        return homeService.talent();
    }

    @GetMapping("/talent/article")
    public Object talentArticle(String articleId){
        return homeService.talentArticle(articleId);
    }

    @GetMapping("/district")
    public Object district(Integer page,Integer tag,Integer type,Integer category) {
        return homeService.district(page,tag,type,category);
    }

    @GetMapping("/brand")
    public Object brand(Integer page,Integer tag) {
        return homeService.brand(page,tag);
    }
}
