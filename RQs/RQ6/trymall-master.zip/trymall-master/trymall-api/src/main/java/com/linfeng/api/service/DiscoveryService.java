package com.linfeng.api.service;

/**
 * @author linfeng
 * @date 2021/1/20 12:37
 */
public interface DiscoveryService {

    String handpick(Integer page);

    String news(Integer page);

    String themeList();

    String theme(Integer themeId);
}
