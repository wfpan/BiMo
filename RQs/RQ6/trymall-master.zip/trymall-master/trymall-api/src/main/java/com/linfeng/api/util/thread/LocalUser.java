package com.linfeng.api.util.thread;

import com.linfeng.common.domain.TrymallUser;

import java.util.HashMap;
import java.util.Map;

/**
 * @author linfeng
 * @date 2021/1/11 15:55
 */
public class LocalUser {

    private static ThreadLocal<Map<String, Object>> threadLocal = new ThreadLocal<>();

    public static void set(TrymallUser user, Integer scope) {
        Map<String, Object> map = new HashMap<>();
        map.put("user", user);
        map.put("scope", scope);
        LocalUser.threadLocal.set(map);
    }

    public static void clear() {
        LocalUser.threadLocal.remove();
    }

    public static TrymallUser getUser() {
        Map<String, Object> map = LocalUser.threadLocal.get();
        TrymallUser user = (TrymallUser)map.get("user");
        return user;
    }

    public static Integer getScope() {
        Map<String, Object> map = LocalUser.threadLocal.get();
        Integer scope = (Integer)map.get("scope");
        return scope;
    }
}
