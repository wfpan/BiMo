package com.linfeng.api.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.linfeng.api.annotation.AdminCheck;
import com.linfeng.api.service.TrymallSystemMessageService;
import com.linfeng.common.domain.TrymallSystemMessage;
import com.linfeng.common.response.ApiCode;
import com.linfeng.common.response.ApiResult;
import com.linfeng.common.vo.SystemMessageVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;


import java.util.List;

/**
 * <p>
 * 系统消息模块 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
@RestController
@RequestMapping("/systemMessage")
@Transactional
public class TrymallSystemMessageController {


    @Autowired
    private TrymallSystemMessageService systemMessageService;

    @GetMapping("/list")
    public ApiResult getList(){
        List<SystemMessageVo> listBySort = systemMessageService.getList();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,listBySort);
    }

    @GetMapping("/article")
    public ApiResult article(String articleId){
        SystemMessageVo message = systemMessageService.article(articleId);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,message);
    }

    @AdminCheck
    @GetMapping("/page")
    public ApiResult page(TrymallSystemMessage message, Page page) {
        Page<TrymallSystemMessage> systemMessagePage = systemMessageService.page(message, page);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,systemMessagePage);
    }

    @GetMapping("/count")
    public ApiResult count(){
        int count = systemMessageService.count();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,count);
    }

    @AdminCheck
    @GetMapping("/single")
    public ApiResult findOne(String systemMessageId){
        TrymallSystemMessage byId = systemMessageService.getById(systemMessageId);
        return ApiResult.result(ApiCode.QUERY_SUCCESS,byId);
    }

    @AdminCheck
    @PostMapping("/create")
    public ApiResult save(@RequestBody TrymallSystemMessage systemMessage){
        if(systemMessageService.save(systemMessage)){
            return ApiResult.result(ApiCode.SUCCESS);
        }
        return ApiResult.result(ApiCode.ERROR);
    }

    @AdminCheck
    @PostMapping("/alter")
    public ApiResult update(@RequestBody TrymallSystemMessage systemMessage){
        if(systemMessageService.updateById(systemMessage)){
            return ApiResult.result(ApiCode.SUCCESS);
        }
        return ApiResult.result(ApiCode.ERROR);
    }

    @AdminCheck
    @PostMapping("/delete/{systemMessageId}")
    public ApiResult delete(@PathVariable String systemMessageId){
        systemMessageService.deleteById(systemMessageId);
        return ApiResult.result(ApiCode.SUCCESS);

    }


}

