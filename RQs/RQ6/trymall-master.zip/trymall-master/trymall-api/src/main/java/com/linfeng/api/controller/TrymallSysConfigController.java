package com.linfeng.api.controller;


import com.linfeng.api.annotation.AdminCheck;
import com.linfeng.api.service.TrymallSysConfigService;
import com.linfeng.common.domain.tbk.TrymallSysConfig;
import com.linfeng.common.response.ApiCode;
import com.linfeng.common.response.ApiResult;
import com.linfeng.common.vo.SystemConfigVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import java.util.List;

/**
 * <p>
 * 系统各种信息模块 前端控制器
 * </p>
 *
 * @author linfeng
 * @since 2021-01-19
 */
@RestController
@RequestMapping("systemConfig")
public class TrymallSysConfigController {

    @Autowired
    private TrymallSysConfigService trymallSysConfigService;

    @GetMapping("/getSystemConfig")
    public ApiResult getSystemConfig(){
        SystemConfigVo systemConfigVo = trymallSysConfigService.getSystemConfigVo();
        return ApiResult.result(ApiCode.QUERY_SUCCESS,systemConfigVo);
    }

    @AdminCheck
    @GetMapping("/single")
    public ApiResult single(){
        List<TrymallSysConfig> list = trymallSysConfigService.list();
        if (list == null || list.size() == 0) {
            return ApiResult.result(ApiCode.EMPTY);
        }
        return ApiResult.result(ApiCode.QUERY_SUCCESS,list.get(0));
    }

    @AdminCheck
    @PostMapping("/create")
    public ApiResult create(@RequestBody TrymallSysConfig sysConfig){
        trymallSysConfigService.create(sysConfig);
        return ApiResult.result(ApiCode.SUCCESS);

    }
}

