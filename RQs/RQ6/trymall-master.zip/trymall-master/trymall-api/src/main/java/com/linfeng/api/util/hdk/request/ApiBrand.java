package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * @author linfeng
 * @date 2021/1/20 13:54
 */
public class ApiBrand extends BaseRequest implements BaseInterface {

    //页数
    private Integer min_id;

    //品牌分类
    private Integer brandcat;

    //返回数据数量
    private Integer back = 20;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/brand";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

    public Integer getMin_id() {
        return min_id;
    }

    public void setMin_id(Integer min_id) {
        this.min_id = min_id;
    }

    public Integer getBrandcat() {
        return brandcat;
    }

    public void setBrandcat(Integer brandcat) {
        this.brandcat = brandcat;
    }
}

