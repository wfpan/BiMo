package com.linfeng.api.util.hdk.request;

import com.linfeng.api.util.HttpRequestMethod;
import com.linfeng.db.base.BaseInterface;
import com.linfeng.db.base.BaseRequest;

/**
 * 达人说API
 * https://www.haodanku.com/Openapi/api_detail?id=23
 * @author linfeng
 * @date 2021/1/19 20:29
 */
public class ApiTalent extends BaseRequest implements BaseInterface {

    /**
     * 大家都在逛类目，文章类别（0.全部，1.好物,2.潮流,3.美食,4.生活）
     */
    private Integer talentcat = 0;

    @Override
    public String getApiUrl() {
        return "http://v2.api.haodanku.com/talent_info";
    }

    @Override
    public String getRequestMethod() {
        return HttpRequestMethod.GET;
    }

}