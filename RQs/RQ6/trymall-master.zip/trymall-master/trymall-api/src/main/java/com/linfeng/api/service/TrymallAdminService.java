package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallAdmin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 管理员 服务类
 * </p>
 *
 * @author linfeng
 * @since 2021-01-20
 */
public interface TrymallAdminService extends IService<TrymallAdmin> {

}
