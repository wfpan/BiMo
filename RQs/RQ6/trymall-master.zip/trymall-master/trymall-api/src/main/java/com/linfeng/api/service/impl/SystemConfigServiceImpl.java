package com.linfeng.api.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.linfeng.api.service.SystemConfigService;
import com.linfeng.common.domain.system.SystemConfig;
import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.db.base.impl.BaseServiceImpl;
import com.linfeng.db.mapper.SystemConfigMapper;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author linfeng
 * @date 2021/1/11 14:10
 */
@Service
@AllArgsConstructor
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true, rollbackFor = Exception.class)
public class SystemConfigServiceImpl extends BaseServiceImpl<SystemConfigMapper, SystemConfig> implements SystemConfigService {


    private final RedisUtils redisUtils;

    @Override
    public String getData(String name) {
        String result = redisUtils.getY(name);
        if(StrUtil.isNotBlank(result)) {
            return result;
        }
        LambdaQueryWrapper<SystemConfig> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SystemConfig::getMenuName,name);
        SystemConfig systemConfig = this.baseMapper.selectOne(wrapper);
        if(systemConfig == null) {
            return "";
        }
        return systemConfig.getValue();
    }

}
