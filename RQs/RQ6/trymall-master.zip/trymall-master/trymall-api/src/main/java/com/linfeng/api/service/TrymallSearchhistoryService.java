package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallSearchhistory;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 搜索历史表 服务类
 * </p>
 *
 * @author linfeng
 * @since 2020-10-18
 */
public interface TrymallSearchhistoryService extends IService<TrymallSearchhistory> {

    public List<TrymallSearchhistory> findByUserId(int userId,int page,int limit);

    public List<TrymallSearchhistory> findAll();

    public TrymallSearchhistory findById(int id);
}
