package com.linfeng.api.service;

import cn.hutool.crypto.SecureUtil;
import com.linfeng.api.redis.util.RedisUtils;
import com.linfeng.common.domain.TrymallBrand;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author linfeng
 * @date 2020/8/27 22:04
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestBrandService {


    @Autowired
    private BrandService brandService;
    @Autowired
    private RedisUtils redisUtils;

    @Test
    public void testBrandFindByDeletedId(){
        TrymallBrand trymallBrand = brandService.findById();
        System.out.println(trymallBrand);
    }

    @Test
    public void testFindByBrandId(){
        TrymallBrand byBrandId = brandService.findByBrandId(1038000);
        System.out.println(byBrandId);
    }


    @Test
    public void testAuth(){

        System.out.println(SecureUtil.md5("123456"));
        redisUtils.set("yjll","hahaha");
        System.out.println(redisUtils.get("yjll"));
    }
}
