package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallSearchhistory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * @author linfeng
 * @date 2020/10/18 15:40
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
public class TestSearchService {

    @Autowired
    private TrymallSearchhistoryService trymallSearchhistoryService;


    @Test
    public void test1(){
        List<TrymallSearchhistory> byUserId = trymallSearchhistoryService.findByUserId(3,1,3);
        System.out.println(byUserId);
    }

    @Test
    public void test2(){
        List<TrymallSearchhistory> all = trymallSearchhistoryService.findAll();
        System.out.println(all);

    }

    @Test
    public void test3(){
        TrymallSearchhistory byId = trymallSearchhistoryService.findById(7);
        System.out.println(byId);

    }

}
