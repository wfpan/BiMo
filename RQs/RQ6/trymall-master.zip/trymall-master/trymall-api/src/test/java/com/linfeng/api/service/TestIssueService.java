package com.linfeng.api.service;

import com.linfeng.common.domain.TrymallIssue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author linfeng
 * @date 2020/8/28 16:46
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TestIssueService {


    @Autowired
    private TrymallIssueService trymallIssueService;

    @Test
    public void test1(){
        List<TrymallIssue> trymallIssues = trymallIssueService.findAll();
        System.out.println(trymallIssues);
    }
}
