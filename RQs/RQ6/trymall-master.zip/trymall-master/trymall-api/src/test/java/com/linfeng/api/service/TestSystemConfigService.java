package com.linfeng.api.service;

import com.linfeng.api.util.oss.QiniuConfig;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author linfeng
 * @date 2021/1/11 14:25
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@Slf4j
public class TestSystemConfigService {

    @Autowired
    private SystemConfigService systemConfigService;
    @Autowired
    private QiniuConfig qiniuConfig;
    @Test
    public void test1(){
        String wxapp_appId = systemConfigService.getData("wxapp_appId");
        log.info(wxapp_appId);
    }

    @Test
    public void test2(){
        log.info(qiniuConfig.getZone());
    }

}
