
package io.linfeng.common.validator.group;

/**
 * 腾讯云
 *
 */
public interface QcloudGroup {
}
