
package io.linfeng.common.validator.group;

/**
 * 更新数据 Group
 *
 */

public interface UpdateGroup {

}
