
package io.linfeng.common.validator.group;

/**
 * 七牛
 *
 */
public interface QiniuGroup {
}
