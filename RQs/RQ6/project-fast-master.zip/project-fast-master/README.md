## project-fast后台管理系统后端权限框架



基于SpringBoot+MybatisPlus+Shiro+Quartz+jwt实现的后台管理系统后端权限框架。

实现了完整的RBAC权限系统。